# TP2 - API REST

## Requisitos
- Node.js instalado

## Instrucciones

1. Instalar dependencias:
```
npm install
```

2. Levantar el servidor:
```
npm start
```

3. Endpoints disponibles:
- `GET /users` → Listar usuarios
- `POST /users` → Agregar usuario
- `PATCH /users/:id` → Actualizar usuario

## Ejemplo JSON para POST o PATCH

```json
{
  "name": "Juan Pérez",
  "age": 20,
  "note": 9
}
```