const User = require('../models/userModel');

let users = [];
let nextId = 1;

exports.getUsers = async () => {
  return users;
};

exports.createUser = async (userData) => {
  const user = new User(nextId++, userData.name, userData.age, userData.note);
  users.push(user);
  return user;
};

exports.updateUser = async (id, updateData) => {
  const user = users.find(u => u.id === parseInt(id));
  if (!user) return null;

  if (updateData.name !== undefined) user.name = updateData.name;
  if (updateData.age !== undefined) user.age = updateData.age;
  if (updateData.note !== undefined) user.note = updateData.note;

  return user;
};