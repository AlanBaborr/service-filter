class User {
  constructor(id, name, age, note) {
    this.id = id;
    this.name = name;
    this.age = age;
    this.note = note;
  }
}

module.exports = User;