const userService = require('../services/userService');

exports.getAllUsers = async (req, res) => {
  const users = await userService.getUsers();
  res.json(users);
};

exports.addUser = async (req, res) => {
  const newUser = await userService.createUser(req.body);
  res.json(newUser);
};

exports.updateUser = async (req, res) => {
  const updatedUser = await userService.updateUser(req.params.id, req.body);
  res.json(updatedUser);
};