import fs from "fs"

export function filterAndWriteArray(array, type) {
    const validTypes = ["string", "number", "boolean"]

    if (!validTypes.includes(type)) {
        return { error: "Tipo de dato inválido." }
    }

    const filteredArray = [...new Set(array.filter(item => typeof item === type))]

    if (filteredArray.length === 0) {
        return { message: "No hay elementos del tipo solicitado." }
    }

    const sortedArray = filteredArray.sort((a, b) => {
        if (type === "string") return a.localeCompare(b)
        if (type === "boolean") return Number(a) - Number(b)
        return a - b
    })

    const content = `Tipo filtrado: ${type}\nDatos: ${JSON.stringify(sortedArray)}`
    fs.writeFileSync("output.txt", content)

    return { result: sortedArray }
}
