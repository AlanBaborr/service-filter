import http from "http"
import fs from "fs"
import { filterAndWriteArray } from "./filter.service.js"
import url from "url"

const data = [2,10,"a",4,"b",6,"d",true,"e",9,1,"z",12,"r", "c", false]

const server = http.createServer(async (req, res) => {
    const { method } = req
    const parsedUrl = url.parse(req.url, true)
    const pathname = parsedUrl.pathname
    const query = parsedUrl.query

    if (method === "GET" && pathname === "/") {
        res.writeHead(200, { "Content-Type": "application/json" })
        res.end(JSON.stringify({ message: "Bienvenido al servicio de filtrado" }))
    } 
    else if (method === "GET" && pathname === "/filtrar") {
        const tipo = query.tipo

        const result = filterAndWriteArray(data, tipo)

        res.writeHead(200, { "Content-Type": "application/json" })
        res.end(JSON.stringify(result))
    } 
    else if (method === "GET" && pathname === "/public") {
        const html = await fs.promises.readFile("./public/index.html", "utf-8")
        res.writeHead(200, { "Content-Type": "text/html" })
        res.end(html)
    } 
    else {
        res.writeHead(404, { "Content-Type": "application/json" })
        res.end(JSON.stringify({ error: "Ruta no encontrada" }))
    }
})

server.listen(8080, () => console.log("Servidor corriendo en http://localhost:8080"))
